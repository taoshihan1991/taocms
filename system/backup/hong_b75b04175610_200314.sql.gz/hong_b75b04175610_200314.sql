DROP TABLE IF EXISTS `hong_acat`;
CREATE TABLE `hong_acat` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `show_sub` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `name_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `desc_cn` text,
  `desc_en` text,
  `counts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  KEY `p_id` (`p_id`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_adposition`;
CREATE TABLE `hong_adposition` (
  `adpoid` int(11) NOT NULL AUTO_INCREMENT,
  `actived` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `width` varchar(16) NOT NULL DEFAULT '',
  `height` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`adpoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_advertise`;
CREATE TABLE `hong_advertise` (
  `adid` int(11) NOT NULL AUTO_INCREMENT,
  `adpoid` int(11) NOT NULL DEFAULT '0',
  `actived` tinyint(1) NOT NULL DEFAULT '1',
  `overdate` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `content_en` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`adid`),
  KEY `adpoid` (`adpoid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_article`;
CREATE TABLE `hong_article` (
  `a_id` int(30) NOT NULL AUTO_INCREMENT,
  `sort` int(30) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `linkurl_en` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext,
  `content_en` mediumtext,
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`a_id`),
  KEY `sort` (`sort`),
  KEY `created` (`created`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_comment`;
CREATE TABLE `hong_comment` (
  `c_id` int(30) NOT NULL AUTO_INCREMENT,
  `for_id` int(30) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `lang` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `actived` tinyint(1) NOT NULL DEFAULT '0',
  `content` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`),
  KEY `for_id` (`for_id`),
  KEY `userid` (`userid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_content`;
CREATE TABLE `hong_content` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `content_en` text,
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  `r_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`),
  KEY `r_id` (`r_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `hong_content` VALUES('1', '关于我们', 'About Us', '&lt;p&gt;
 &lt;span style=&quot;margin:0px;padding:0px;color:#333333;text-transform:none;line-height:27px;text-indent:0px;letter-spacing:normal;font-family:宋体;font-size:12px;font-style:normal;font-weight:400;word-spacing:0px;white-space:normal;orphans:2;widows:2;background-color:#FAFAFA;font-variant-ligatures:normal;font-variant-caps:normal;-webkit-text-stroke-width:0px;text-decoration-style:initial;text-decoration-color:initial;&quot;&gt;临清市亿联轴承有限公司座落于山东省临清朱庄工业园。这里地理位置十分优越，东靠京九铁路，西临京广干线，南近济聊馆高速公路，北依国道308线 ，省道008线穿境而过。 我公司是一家集研发、设计、生产、销售于一体的轴承制造企业。公司始建于2014年，由手工作坊，逐渐发展壮大，2015年正式纳入规范企业，注册商标为DUZ。经过多年的制造销售经验、人才和客户的积累，亿联轴承在深沟球进出口行业中迅速崛起。 如今公司新建标准生产厂房，占地面积1500平方米，拥有员工50余人，技术研发人员达10人。公司配备先进的生产设备和检测仪器：包括自动磨床、自动超精机、装配合套仪、大型清洗机等精密设备，保证了我们的生产实力和轴承品质的稳定性。 公司专业生产深沟球轴承 外球面轴承 组装圆锥滚子轴承 调心球轴承推力滚子轴承以及各种非标异性轴承系列&lt;br /&gt;
主要产品有：&lt;br /&gt;
1、深沟球轴承&lt;br /&gt;
2、公制圆锥滚子轴承、英制圆锥滚子轴承&lt;br /&gt;
3、各种带座外球面轴承&lt;br /&gt;
4、调心球轴承&lt;br /&gt;
5、推力子轴承&lt;br /&gt;
6、圆柱滚子轴承&lt;span style=&quot;margin:0px;padding:0px;color:#333333;text-transform:none;line-height:27px;text-indent:0px;letter-spacing:normal;font-family:宋体;font-size:12px;font-style:normal;font-weight:400;word-spacing:0px;white-space:normal;orphans:2;widows:2;background-color:#FAFAFA;font-variant-ligatures:normal;font-variant-caps:normal;-webkit-text-stroke-width:0px;text-decoration-style:initial;text-decoration-color:initial;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;/span&gt; 
&lt;/p&gt;', '&lt;p&gt;
&lt;span style=&quot;margin:0px;padding:0px;color:#333333;text-transform:none;line-height:27px;text-indent:0px;letter-spacing:normal;font-family:宋体;font-size:12px;font-style:normal;font-weight:400;word-spacing:0px;white-space:normal;orphans:2;widows:2;background-color:#FAFAFA;font-variant-ligatures:normal;font-variant-caps:normal;-webkit-text-stroke-width:0px;text-decoration-style:initial;text-decoration-color:initial;&quot;&gt;LINQING YILIAN BEARING CO .,LTD IN ZHUZHUANG LINQING CITY SHANDONG .ITS A SET RESEARCH AND DEVELOPMENT,PRODUCTION,SALES AS ONE OF THE HIGH PRECISION BEARING MANUFACTURING COMPANY.WE SECIALIZING IN THE PRODUCTION OF DEEP GROOVE BALL BEARING ,PILLOW BLOCK BEARING ,AND VARIOUS NON-STANDARD BEARINGS ,MEAN WHILE WELCOME OEM COOPERATION PROJECTS.&lt;/span&gt;
&lt;/p&gt;', '关于,我们', 'about us', '1381928888', '1');
INSERT INTO `hong_content` VALUES('2', '联系我们', 'Contact Us', '&lt;span style=&quot;white-space:nowrap;&quot;&gt;联系人: 曹经理&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;E-mail: yybearing@vip.163.com&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;地址: 山东临清朱庄工业园区&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;QQ: 497938422&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;手机: &lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;15069500372&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt; 13563028002&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt; 13256425128&lt;/span&gt;&lt;br /&gt;', '&lt;h5&gt;
 Linqing Yilian Beraring Co.,Ltd.
&lt;/h5&gt;
&lt;table&gt;
 &lt;tbody&gt;
  &lt;tr&gt;
   &lt;td&gt;
    Phone：
   &lt;/td&gt;
   &lt;td&gt;
    +86-15069500372
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    QQ：
   &lt;/td&gt;
   &lt;td&gt;
    497938422
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    Email：
   &lt;/td&gt;
   &lt;td&gt;
    yybearing@vip.163.com
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    WECHAT：
   &lt;/td&gt;
   &lt;td&gt;
    CAO497938422
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    Contacts：
   &lt;/td&gt;
   &lt;td&gt;
    Mrs. Cao
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;margin:0px;padding:0px;border:0px;outline:0px;vertical-align:baseline;background:transparent;&quot;&gt;
   &lt;td&gt;
    Add：
   &lt;/td&gt;
   &lt;td&gt;
    Zhu Zhuang Industrial Park&lt;br /&gt;
Linqing Shandong
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;', '联系,我们', 'contact us', '1381928888', '2');
INSERT INTO `hong_content` VALUES('3', '首页常态内容', 'Homepage content', '请在后台管理中自定义首页常态内容.', 'please edit your homepage content.', 'hongcms中英文企业网站系统', 'hongcms,website system', '1381928888', '3');
INSERT INTO `hong_content` VALUES('4', '底部信息', '底部信息', '电话：15069500372 13563028002 13256425128 QQ：497938422&lt;br /&gt;
Copyright © 2018-2019 临清市亿联轴承有限公司&lt;br /&gt;', 'Tel:+86-15069500372 QQ:497938422 WECHAT:CAO497938422&lt;br /&gt;
Copyright © 2018-2019 Linqing Yilian Bearing Co.,Ltd.&lt;br /&gt;', '底部信息', '底部信息', '1381928888', '11');
INSERT INTO `hong_content` VALUES('5', '第二个公司', 'The second Company', '请在后台管理常态内容中自定义第二个公司详细介绍.', 'please edit The second Company content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '12');
INSERT INTO `hong_content` VALUES('6', '第三个公司', 'The third Company', '请在后台管理常态内容中自定义第三个公司详细介绍.', 'please edit The third Company content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '13');
INSERT INTO `hong_content` VALUES('7', '企业文化', 'Our Culture', '请在后台管理常态内容中自定义企业文化详细内容.', 'please edit Our Culture content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '14');
INSERT INTO `hong_content` VALUES('8', '组织结构', 'Organization', '请在后台管理常态内容中自定义组织结构详细内容.', 'please edit Organization content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '15');



DROP TABLE IF EXISTS `hong_enquiry`;
CREATE TABLE `hong_enquiry` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `refer_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(128) NOT NULL DEFAULT '',
  `pro_id` int(30) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `lang` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`e_id`),
  KEY `userid` (`userid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_gimage`;
CREATE TABLE `hong_gimage` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(30) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `path` varchar(255) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`g_id`),
  KEY `pro_id` (`pro_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `hong_gimage` VALUES('1', '1', '1', '2020/0314', '2fe99fbf09ebc5a655401e44ece1938f');
INSERT INTO `hong_gimage` VALUES('2', '1', '1', '2020/0314', '588b18b63a0e07871dbe91710205413a');
INSERT INTO `hong_gimage` VALUES('3', '1', '1', '2020/0314', '8fdefeab4f03f8a282da81d145372aba');



DROP TABLE IF EXISTS `hong_news`;
CREATE TABLE `hong_news` (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `linkurl_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext,
  `content_en` mediumtext,
  `clicks` int(30) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`n_id`),
  KEY `sort` (`sort`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_pcat`;
CREATE TABLE `hong_pcat` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `show_sub` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `name_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `desc_cn` text,
  `desc_en` text,
  `counts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  KEY `p_id` (`p_id`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `hong_pcat` VALUES('1', '0', '1', '1', '1', '深沟球轴承', 'DEEP GROOVE BALL BEARING', '', '', '', '', '0');
INSERT INTO `hong_pcat` VALUES('2', '1', '2', '1', '1', '6000 系列', '6000 SERIES', '', '', '', '', '1');
INSERT INTO `hong_pcat` VALUES('3', '0', '3', '1', '1', '圆锥滚子轴承', 'taper roller bearing', '圆锥滚子轴承', '', '', '', '0');



DROP TABLE IF EXISTS `hong_pm`;
CREATE TABLE `hong_pm` (
  `pmid` int(30) NOT NULL AUTO_INCREMENT,
  `refer_id` int(30) NOT NULL DEFAULT '0',
  `toid` int(11) NOT NULL DEFAULT '0',
  `toname` varchar(64) NOT NULL DEFAULT '',
  `fromid` int(11) NOT NULL DEFAULT '0',
  `fromname` varchar(64) NOT NULL DEFAULT '',
  `readed` tinyint(1) NOT NULL DEFAULT '0',
  `newreply` tinyint(1) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pmid`),
  KEY `refer_id` (`refer_id`),
  KEY `toid` (`toid`),
  KEY `fromid` (`fromid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_product`;
CREATE TABLE `hong_product` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `price` varchar(36) NOT NULL DEFAULT '',
  `price_en` varchar(36) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext,
  `content_en` mediumtext,
  `clicks` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`),
  KEY `sort` (`sort`),
  KEY `created` (`created`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `hong_product` VALUES('1', '2', '1', '1', '1', '1', '系统管理员', '2020/0314', '7dcfb78ade509e4f3f9eb4668322aba1', '', '', '推力球轴承', 'Thrust Ball Bearing', '51100  51200 系列', '51100  51200 series', '&lt;br /&gt;
&lt;table width=&quot;96%&quot; align=&quot;center&quot; cellspacing=&quot;1&quot; style=&quot;font-size:12px;color:#FFFFFF;font-family:Verdana, Arial, Helvetica, sans-serif, 宋体;&quot;&gt;
 &lt;tbody&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    轴承型号
   &lt;/td&gt;
   &lt;td colspan=&quot;4&quot; align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    外型尺寸（mm）
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    重量（kg）
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    d
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    D
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    T
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    rsmin
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51103
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    17
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    9
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.3
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.024
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51203
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    17
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    12
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.048
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51104
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    10
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.3
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.036
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51204
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.075
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51304
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    47
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.146
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    42
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    11
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.055
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51205
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    47
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    15
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.11
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51305
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    52
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.18
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51405
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    24
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.33
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51106
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    47
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    11
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.062
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51206
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    52
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    16
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.13
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51306
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    21
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.27
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51406
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    28
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.52
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51107
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    52
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    12
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.077
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51207
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    62
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.21
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51307
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    68
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    24
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.38
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51407
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    32
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.76
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51108
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    13
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.11
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51208
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    68
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.26
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51308
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    78
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    26
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.55
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51408
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    36
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.08
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51708ZH
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    67
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14.25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.146
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51109
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.15
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51209
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    73
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.32
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51309
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    28
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.68
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51409
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    39
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.43
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.16
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51210
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    78
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    22
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.38
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51310
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    95
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    31
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.95
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51410
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    43
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.9
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51111
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    78
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    16
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.23
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51211
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.61
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51311
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.29
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51411
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    48
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.52
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51112
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    17
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.3
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51212
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    95
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    26
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.68
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51312
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.37
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51412
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    130
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    3.12
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51113
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.34
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51213
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.78
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51313
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    115
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    36
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.51
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51413
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    140
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    56
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    3.96
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51114
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    95
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.36
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51214
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.79
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51314
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    125
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.01
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51414
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    150
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    4.86
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51115
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.4
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51215
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.87
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51315
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    135
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    44
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.61
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51415
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    160
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    5.97
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51116
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.42
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51216
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    115
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    28
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.92
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51316
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    140
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    44
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.72
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51416
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    170
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    68
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    7.77
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51117
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.45
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51217
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    125
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    31
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.25
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51118
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    22
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.69
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51218
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    135
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.7
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    135
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51220
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    150
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    38
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.3
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51122
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    145
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.08
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51124
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    155
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.12
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td colspan=&quot;6&quot; align=&quot;left&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    非标准
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51105K1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    43
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    10
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.04
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51105K2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    43
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    10
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.041
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    688808
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    67
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14.25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.25
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;', '&lt;div style=&quot;text-align:center;&quot;&gt;
 &lt;span style=&quot;color:#974D04;font-family:Arial, Helvetica, sans-serif;font-size:20px;line-height:20px;text-align:center;&quot;&gt;Thrust Ball Bearing&lt;/span&gt;
&lt;/div&gt;
&lt;table width=&quot;600&quot; border=&quot;0&quot; align=&quot;center&quot; cellpadding=&quot;0&quot; cellspacing=&quot;0&quot; style=&quot;color:#000000;font-family:Simsun;text-align:center;&quot; class=&quot;ke-zeroborder&quot;&gt;
 &lt;tbody&gt;
  &lt;tr&gt;
   &lt;td class=&quot;main_4_e&quot; style=&quot;font-size:13px;line-height:20px;font-family:Arial, Helvetica, sans-serif;color:#47472D;text-align:justify;&quot;&gt;
    This type of bearings is separable ,which can only carry axial load,The single direction bearings of them can only carry axial load in one direction,while the double can carry slternating axial load in either diredtion.Before using they have to be preloaded.The thrust ball bearings are used in lathe centers,automobile clutches,reducers and so on ,The double direction angular contact thrust ball bearings are suitable for machine tool spindles,while the single are used to support ball screws.
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td colspan=&quot;4&quot;&gt;
    &lt;table width=&quot;480&quot; border=&quot;0&quot; align=&quot;center&quot; cellpadding=&quot;20&quot; class=&quot;ke-zeroborder&quot;&gt;
     &lt;tbody&gt;
      &lt;tr&gt;
       &lt;td align=&quot;center&quot;&gt;
        &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/03.jpg&quot; alt=&quot;&quot; /&gt;
       &lt;/td&gt;
       &lt;td align=&quot;center&quot;&gt;
        &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/04.jpg&quot; alt=&quot;&quot; /&gt;
       &lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
       &lt;td colspan=&quot;2&quot; align=&quot;center&quot;&gt;
        &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/1-2.jpg&quot; alt=&quot;&quot; /&gt;
       &lt;/td&gt;
      &lt;/tr&gt;
     &lt;/tbody&gt;
    &lt;/table&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;
&lt;table width=&quot;750&quot; border=&quot;0&quot; align=&quot;center&quot; cellpadding=&quot;0&quot; cellspacing=&quot;0&quot; style=&quot;color:#000000;font-family:Simsun;text-align:center;&quot; class=&quot;ke-zeroborder&quot;&gt;
 &lt;tbody&gt;
  &lt;tr&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_01.gif&quot; width=&quot;200&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_02.gif&quot; width=&quot;175&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_03.gif&quot; width=&quot;185&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_04.gif&quot; width=&quot;190&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_05.gif&quot; width=&quot;200&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_06.gif&quot; width=&quot;175&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_07.gif&quot; width=&quot;185&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_08.gif&quot; width=&quot;190&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_09.gif&quot; width=&quot;200&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_10.gif&quot; width=&quot;175&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_11.gif&quot; width=&quot;185&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_12.gif&quot; width=&quot;190&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;', '1', '1584179432');



DROP TABLE IF EXISTS `hong_session`;
CREATE TABLE `hong_session` (
  `sessionid` char(32) NOT NULL DEFAULT '',
  `userid` int(11) NOT NULL DEFAULT '0',
  `ipaddress` varchar(32) NOT NULL DEFAULT '',
  `useragent` char(32) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sessionid`),
  KEY `userid` (`userid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `hong_session` VALUES('09a2c1953eaab1d855bfaa9b5ab711db', '1', '127.0.0.1', '71a10afe9f5fcd7fc10e40d020fb6143', '1584169972', '1');
INSERT INTO `hong_session` VALUES('e648de83d4d9b3e9ac5f69a2ec50855a', '1', '127.0.0.1', '08bc4d08dd080581a19b641d24734b6b', '1584177354', '1');



DROP TABLE IF EXISTS `hong_user`;
CREATE TABLE `hong_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `verifycode` varchar(8) NOT NULL DEFAULT '',
  `joindate` int(11) NOT NULL DEFAULT '0',
  `lastdate` int(11) NOT NULL DEFAULT '0',
  `joinip` varchar(64) NOT NULL DEFAULT '',
  `lastip` varchar(64) NOT NULL DEFAULT '',
  `lang` tinyint(1) NOT NULL DEFAULT '0',
  `loginnum` int(11) NOT NULL DEFAULT '0',
  `p_num` int(11) NOT NULL DEFAULT '0',
  `a_num` int(11) NOT NULL DEFAULT '0',
  `q_num` int(11) NOT NULL DEFAULT '0',
  `pc_num` int(11) NOT NULL DEFAULT '0',
  `ac_num` int(11) NOT NULL DEFAULT '0',
  `nickname` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `profile` text,
  `company` varchar(225) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `postcode` varchar(32) NOT NULL DEFAULT '',
  `tel` varchar(255) NOT NULL DEFAULT '',
  `fax` varchar(255) NOT NULL DEFAULT '',
  `online` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  KEY `joindate` (`joindate`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `hong_user` VALUES('1', '1', '1', 'tsh1991', '4c49dc3fc55e22983caa24088c99e8c9', '', '1584169944', '1584177354', 'unknown', '127.0.0.1', '1', '2', '1', '0', '0', '0', '0', '系统管理员', '', NULL, '', '', '', '', '', '', '');



DROP TABLE IF EXISTS `hong_usergroup`;
CREATE TABLE `hong_usergroup` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `grouptype` tinyint(1) NOT NULL DEFAULT '0',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `groupname_en` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `actions` text,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `hong_usergroup` VALUES('1', '1', '超级管理员', 'Administrator', '超级管理员, 具有前后台所有权限, 且权限无法更改', 'all');
INSERT INTO `hong_usergroup` VALUES('2', '0', '注册会员', 'Member', '用户在前台注册后的默认用户组', '*login*comment*enquiry*pmdays:30*');
INSERT INTO `hong_usergroup` VALUES('3', '0', '游客', 'Guest', '前台未注册的浏览者', '*enquiry*');



DROP TABLE IF EXISTS `hong_vvc`;
CREATE TABLE `hong_vvc` (
  `vvcid` int(30) NOT NULL AUTO_INCREMENT,
  `code` varchar(9) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vvcid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




