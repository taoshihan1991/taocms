DROP TABLE IF EXISTS `hong_acat`;
CREATE TABLE `hong_acat` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `show_sub` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `name_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `desc_cn` text,
  `desc_en` text,
  `counts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  KEY `p_id` (`p_id`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hong_acat` VALUES('1', '0', '1', '1', '0', '常见问题', 'Service', '', '', '', '', '2');
INSERT INTO `hong_acat` VALUES('2', '0', '2', '1', '0', '新闻动态', 'News', '', '', '', '', '0');



DROP TABLE IF EXISTS `hong_adposition`;
CREATE TABLE `hong_adposition` (
  `adpoid` int(11) NOT NULL AUTO_INCREMENT,
  `actived` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `width` varchar(16) NOT NULL DEFAULT '',
  `height` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`adpoid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_advertise`;
CREATE TABLE `hong_advertise` (
  `adid` int(11) NOT NULL AUTO_INCREMENT,
  `adpoid` int(11) NOT NULL DEFAULT '0',
  `actived` tinyint(1) NOT NULL DEFAULT '1',
  `overdate` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `content_en` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`adid`),
  KEY `adpoid` (`adpoid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_article`;
CREATE TABLE `hong_article` (
  `a_id` int(30) NOT NULL AUTO_INCREMENT,
  `sort` int(30) NOT NULL DEFAULT '0',
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '0',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `linkurl_en` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext,
  `content_en` mediumtext,
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`a_id`),
  KEY `sort` (`sort`),
  KEY `created` (`created`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hong_article` VALUES('1', '1', '1', '1', '0', '1', '系统管理员', '滚动轴承类型的选择', 'No English Title!', '', '', '&lt;span style=&quot;white-space:nowrap;&quot;&gt;选择滚动轴承类型时，应考虑轴承的工作载荷（大小、性质、方向）、转速及其它使用要求。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;1)转速较高、载荷较小、要求旋转精度高时宜选用球轴承；转速较低、载荷较大或有冲击载荷时则选用滚子轴承。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;2)轴承上同时受径向和轴向联合载荷，一般选用角接触球轴承或圆锥滚子轴承；若径向载荷较大、轴向载荷小，可选用深沟球轴承；而当轴向载荷较大、径向载荷小时，可采用推力角接触球轴承、四点接触球轴承或选用推力球轴承和深沟球轴承的组合结构。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;3)各类轴承使用时内、外圈间的倾斜角应控制在允许角偏斜值之内，否则会增大轴承的附加载荷而降低寿命。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;4)刚度要求较大的轴系，宜选用双列球轴承、滚子轴承或四点接触球轴承，载荷特大或有较大冲击力时可在同一支点上采用双列或多列滚子轴承。轴承系统的刚度高可提高轴的旋转精度、减少振动噪声。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;5)为便于安装拆卸和调整间隙常选用内、外圈可分离的分离型轴承（如圆锥滚子轴承、四点接触球轴承）。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;6)选轴承时应注意经济性。球轴承比滚子轴承便宜。同型号尺寸公差等级为P0、P6、P5、P4、P2、的滚动轴承。&lt;/span&gt;&lt;br /&gt;', '', '', '', '1', '1584258855');
INSERT INTO `hong_article` VALUES('2', '2', '1', '1', '0', '1', '系统管理员', '深沟球轴承的工作原理及主要用途', 'No English Title!', '', '', '&lt;p&gt;
 深沟球轴承的工作原理：
&lt;/p&gt;
&lt;p&gt;
 深沟球轴承进口轴承主要用于承受纯径向载荷，也可同时承受径向载荷和轴向载荷。当其仅承受纯径向载荷时，接触角为零。当深沟球轴承具有较大的径向游隙时，具有角接触轴承的性能，可承受较大的轴向载荷 。深沟球轴承的摩擦系数很小，极限转速也很高， 特别是在轴向载荷很大的高速运转工况下，深沟球轴承比推力球轴承更有优越性。
&lt;/p&gt;
&lt;p&gt;
 深沟球轴承的主要用途：
&lt;/p&gt;
&lt;p&gt;
 深沟球轴承是代表性的滚动轴承，用途广泛。适用于高转速甚至极高转速的运行，而且非常耐用，无需经常维护。该类轴承摩擦系数小，极限转速高， 结构简单，制造成本低，易达到较高制造精度。 尺寸范围与形式变化多样，应用在精密仪表、低噪音电机、汽车、摩托车及一般机械等行业，是机械工业中使用最为广泛的一类轴承。主要承受径向负荷，也可承受一定量的轴向负荷深沟球轴承可用于变速箱、仪器仪表、电机、家用电器、内燃机、交通车辆、农业机械、建筑机械、工程机械等。
&lt;/p&gt;
&lt;br /&gt;', '&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;深沟球轴承的工作原理： &lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;深沟球轴承进口轴承主要用于承受纯径向载荷，也可同时承受径向载荷和轴向载荷。当其仅承受纯径向载荷时，接触角为零。当深沟球轴承具有较大的径向游隙时，&lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;具有角接触轴承的性能，可承受较大的轴向载荷 。深沟球轴承的摩擦系数很小，极限转速也很高， &lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;特别是在轴向载荷很大的高速运转工况下，深沟球轴承比推力球轴承更有优越性。 &lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;深沟球轴承的主要用途： &lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt; 深沟球轴承是代表性的滚动轴承，用途广泛。适用于高转速甚至极高转速的运行，而且非常耐用，无需经常维护。&lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;该类轴承摩擦系数小，极限转速高， 结构简单，制造成本低，易达到较高制造精度。 &lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;尺寸范围与形式变化多样，应用在精密仪表、低噪音电机、汽车、摩托车及一般机械等行业，是机械工业中使用最为广泛的一类轴承。&lt;/span&gt; 
&lt;/p&gt;
&lt;p&gt;
 &lt;span style=&quot;white-space:nowrap;&quot;&gt;主要承受径向负荷，也可承受一定量的轴向负荷深沟球轴承可用于变速箱、仪器仪表、电机、家用电器、内燃机、交通车辆、农业机械、建筑机械、工程机械等。 &lt;/span&gt; 
&lt;/p&gt;', '', '', '1', '1584260625');



DROP TABLE IF EXISTS `hong_comment`;
CREATE TABLE `hong_comment` (
  `c_id` int(30) NOT NULL AUTO_INCREMENT,
  `for_id` int(30) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `lang` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `actived` tinyint(1) NOT NULL DEFAULT '0',
  `content` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`),
  KEY `for_id` (`for_id`),
  KEY `userid` (`userid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_content`;
CREATE TABLE `hong_content` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `content_en` text,
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  `r_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`c_id`),
  KEY `r_id` (`r_id`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `hong_content` VALUES('1', '关于我们', 'About Us', '&lt;p&gt;
 &lt;span style=&quot;margin:0px;padding:0px;color:#333333;text-transform:none;line-height:27px;text-indent:0px;letter-spacing:normal;font-family:宋体;font-size:12px;font-style:normal;font-weight:400;word-spacing:0px;white-space:normal;orphans:2;widows:2;background-color:#FAFAFA;font-variant-ligatures:normal;font-variant-caps:normal;-webkit-text-stroke-width:0px;text-decoration-style:initial;text-decoration-color:initial;&quot;&gt;临清市亿联轴承有限公司座落于山东省临清朱庄工业园。这里地理位置十分优越，东靠京九铁路，西临京广干线，南近济聊馆高速公路，北依国道308线 ，省道008线穿境而过。 我公司是一家集研发、设计、生产、销售于一体的轴承制造企业。公司始建于2014年，由手工作坊，逐渐发展壮大，2015年正式纳入规范企业，注册商标为DUZ。经过多年的制造销售经验、人才和客户的积累，亿联轴承在深沟球进出口行业中迅速崛起。 如今公司新建标准生产厂房，占地面积1500平方米，拥有员工50余人，技术研发人员达10人。公司配备先进的生产设备和检测仪器：包括自动磨床、自动超精机、装配合套仪、大型清洗机等精密设备，保证了我们的生产实力和轴承品质的稳定性。 公司专业生产深沟球轴承 外球面轴承 组装圆锥滚子轴承 调心球轴承推力滚子轴承以及各种非标异性轴承系列&lt;br /&gt;
主要产品有：&lt;br /&gt;
1、深沟球轴承&lt;br /&gt;
2、公制圆锥滚子轴承、英制圆锥滚子轴承&lt;br /&gt;
3、各种带座外球面轴承&lt;br /&gt;
4、调心球轴承&lt;br /&gt;
5、推力子轴承&lt;br /&gt;
6、圆柱滚子轴承&lt;span style=&quot;margin:0px;padding:0px;color:#333333;text-transform:none;line-height:27px;text-indent:0px;letter-spacing:normal;font-family:宋体;font-size:12px;font-style:normal;font-weight:400;word-spacing:0px;white-space:normal;orphans:2;widows:2;background-color:#FAFAFA;font-variant-ligatures:normal;font-variant-caps:normal;-webkit-text-stroke-width:0px;text-decoration-style:initial;text-decoration-color:initial;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;/span&gt; 
&lt;/p&gt;', '&lt;p&gt;
&lt;span style=&quot;margin:0px;padding:0px;color:#333333;text-transform:none;line-height:27px;text-indent:0px;letter-spacing:normal;font-family:宋体;font-size:12px;font-style:normal;font-weight:400;word-spacing:0px;white-space:normal;orphans:2;widows:2;background-color:#FAFAFA;font-variant-ligatures:normal;font-variant-caps:normal;-webkit-text-stroke-width:0px;text-decoration-style:initial;text-decoration-color:initial;&quot;&gt;LINQING YILIAN BEARING CO .,LTD IN ZHUZHUANG LINQING CITY SHANDONG .ITS A SET RESEARCH AND DEVELOPMENT,PRODUCTION,SALES AS ONE OF THE HIGH PRECISION BEARING MANUFACTURING COMPANY.WE SECIALIZING IN THE PRODUCTION OF DEEP GROOVE BALL BEARING ,PILLOW BLOCK BEARING ,AND VARIOUS NON-STANDARD BEARINGS ,MEAN WHILE WELCOME OEM COOPERATION PROJECTS.&lt;/span&gt;
&lt;/p&gt;', '关于,我们', 'about us', '1381928888', '1');
INSERT INTO `hong_content` VALUES('2', '联系我们', 'Contact Us', '&lt;span style=&quot;white-space:nowrap;&quot;&gt;联系人: 曹经理&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;E-mail: yybearing@vip.163.com&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;地址: 山东临清朱庄工业园区&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;QQ: 497938422&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;手机: &lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;15069500372&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt; 13563028002&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt; 13256425128&lt;/span&gt;&lt;br /&gt;', '&lt;h5&gt;
 Linqing Yilian Beraring Co.,Ltd.
&lt;/h5&gt;
&lt;table&gt;
 &lt;tbody&gt;
  &lt;tr&gt;
   &lt;td&gt;
    Phone：
   &lt;/td&gt;
   &lt;td&gt;
    +86-15069500372
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    QQ：
   &lt;/td&gt;
   &lt;td&gt;
    497938422
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    Email：
   &lt;/td&gt;
   &lt;td&gt;
    yybearing@vip.163.com
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    WECHAT：
   &lt;/td&gt;
   &lt;td&gt;
    CAO497938422
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    Contacts：
   &lt;/td&gt;
   &lt;td&gt;
    Mrs. Cao
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;margin:0px;padding:0px;border:0px;outline:0px;vertical-align:baseline;background:transparent;&quot;&gt;
   &lt;td&gt;
    Add：
   &lt;/td&gt;
   &lt;td&gt;
    Zhu Zhuang Industrial Park&lt;br /&gt;
Linqing Shandong
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;', '联系,我们', 'contact us', '1381928888', '2');
INSERT INTO `hong_content` VALUES('3', '首页常态内容', 'Homepage content', '请在后台管理中自定义首页常态内容.', 'please edit your homepage content.', 'hongcms中英文企业网站系统', 'hongcms,website system', '1381928888', '3');
INSERT INTO `hong_content` VALUES('4', '底部信息', '底部信息', '电话：15069500372 13563028002 13256425128 QQ：497938422&lt;br /&gt;
Copyright © 2018-2020 临清市亿联轴承有限公司&lt;br /&gt;', 'Tel:+86-15069500372 QQ:497938422 WECHAT:CAO497938422&lt;br /&gt;
Copyright © 2018-2019 Linqing Yilian Bearing Co.,Ltd.&lt;br /&gt;', '底部信息', '底部信息', '1381928888', '11');
INSERT INTO `hong_content` VALUES('5', '在线留言', 'FeedBack', '&lt;h3&gt;
 &lt;br /&gt;
&lt;/h3&gt;
&lt;h3&gt;
 如果您对某样产品感兴趣 ， 可以点击详细产品页中的询价按钮
&lt;/h3&gt;
&lt;p&gt;
&lt;/p&gt;
&lt;p&gt;
 &lt;br /&gt;
&lt;/p&gt;
&lt;p&gt;
 &lt;img src=&quot;/uploads/image/2020/0315/20200315173308_95462.jpg&quot; alt=&quot;&quot; /&gt; 
&lt;/p&gt;', '&lt;h3&gt;
 &lt;br /&gt;
&lt;/h3&gt;
&lt;h3&gt;
 If you are interested in a certain product, you can click the inquiry button in the detailed product page
&lt;/h3&gt;
&lt;p&gt;
&lt;/p&gt;
&lt;p&gt;
 &lt;br /&gt;
&lt;/p&gt;
&lt;p&gt;
 &lt;img src=&quot;/uploads/image/2020/0315/20200315173308_95462.jpg&quot; alt=&quot;&quot; /&gt; 
&lt;/p&gt;', '在线留言', 'FeedBack', '1381928888', '12');
INSERT INTO `hong_content` VALUES('6', '第三个公司', 'The third Company', '请在后台管理常态内容中自定义第三个公司详细介绍.', 'please edit The third Company content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '13');
INSERT INTO `hong_content` VALUES('7', '企业文化', 'Our Culture', '请在后台管理常态内容中自定义企业文化详细内容.', 'please edit Our Culture content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '14');
INSERT INTO `hong_content` VALUES('8', '组织结构', 'Organization', '请在后台管理常态内容中自定义组织结构详细内容.', 'please edit Organization content on back-end.', 'hongcms,website system', 'hongcms,website system', '1381928888', '15');



DROP TABLE IF EXISTS `hong_enquiry`;
CREATE TABLE `hong_enquiry` (
  `e_id` int(11) NOT NULL AUTO_INCREMENT,
  `refer_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(128) NOT NULL DEFAULT '',
  `pro_id` int(30) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `lang` tinyint(1) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`e_id`),
  KEY `userid` (`userid`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hong_enquiry` VALUES('1', '0', '2', '630892807@qq.com', '1', '0', 'taocms', '0', 'test', 'ceshi test', '1584264268');
INSERT INTO `hong_enquiry` VALUES('2', '1', '1', '', '0', '1', '系统管理员', '0', '', 'shia', '1584264312');



DROP TABLE IF EXISTS `hong_gimage`;
CREATE TABLE `hong_gimage` (
  `g_id` int(11) NOT NULL AUTO_INCREMENT,
  `pro_id` int(30) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `path` varchar(255) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`g_id`),
  KEY `pro_id` (`pro_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `hong_gimage` VALUES('1', '1', '1', '2020/0314', '2fe99fbf09ebc5a655401e44ece1938f');
INSERT INTO `hong_gimage` VALUES('2', '1', '1', '2020/0314', '588b18b63a0e07871dbe91710205413a');
INSERT INTO `hong_gimage` VALUES('3', '1', '1', '2020/0314', '8fdefeab4f03f8a282da81d145372aba');
INSERT INTO `hong_gimage` VALUES('4', '2', '1', '2020/0315', '0f62f68a8627df9e6f885b81b8b91feb');
INSERT INTO `hong_gimage` VALUES('5', '2', '1', '2020/0315', '6931073e26e91ac28f32b599cdc1d060');
INSERT INTO `hong_gimage` VALUES('6', '2', '1', '2020/0315', '81e8168b48f8cabf6ed5e42ef7b75d0a');



DROP TABLE IF EXISTS `hong_news`;
CREATE TABLE `hong_news` (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `linkurl` varchar(255) NOT NULL DEFAULT '',
  `linkurl_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext,
  `content_en` mediumtext,
  `clicks` int(30) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`n_id`),
  KEY `sort` (`sort`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `hong_news` VALUES('1', '1', '1', '讨论深沟球轴承的胶盖和铁盖的优缺点', 'No English Title!', '', '', '', '', '&lt;span style=&quot;white-space:nowrap;&quot;&gt;密封型深沟球轴承有胶盖密封和铁盖密封之分，很多客户不知道如何区分这两种类型的区别，下面就听隆洋轴承给大家介绍下。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;轴承密封盖的作用主要是防止外部异物侵入（固体异物、液态异物），防止轴承润滑剂损失。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;轴承密封盖的密封形式有两种：&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;一、非接触式密封盖（密封盖和内圈没有接触的），包括冲压钢板密封盖（铁封闭）和非接触式橡胶密封盖。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;优点：防尘、相对转速高、金属密封盖相对静音效果低、价格相对稍低。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;缺点：无法防止液态异物侵入。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;二、是接触式密封盖（密封盖和轴承的内圈有单唇或多唇接触），包括接触式橡胶密封盖和迷宫式接触密封盖。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;优点：防尘、防液态异物、静音效果高。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;缺点：转速稍低、价格稍高。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;所以，深沟球轴承密封盖没有好坏的区别，只有合不合适的区别。例如：在洁净的环境中就不必要用接触式橡胶密封盖，这样只会增加厂家额外的成本。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;综上所述，密封型式没有好坏之分，主要考虑轴承用在哪里，需要考虑轴承的使用环境因素，实际上就是密封效果和磨擦系数。&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;&lt;br /&gt;
&lt;/span&gt;&lt;br /&gt;
&lt;span style=&quot;white-space:nowrap;&quot;&gt;密封圈结构不同，材料不同，磨擦系数也就不同，如果高转速以选择高磨擦系数的轴承，那么轴承很快就会坏；另外就是防尘效果的不同。所以选对轴承在选择轴承的胶封或者密封时要考虑很多的因素。&lt;/span&gt;&lt;br /&gt;', '', '1', '1584259726');



DROP TABLE IF EXISTS `hong_pcat`;
CREATE TABLE `hong_pcat` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `show_sub` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL DEFAULT '',
  `name_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `desc_cn` text,
  `desc_en` text,
  `counts` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cat_id`),
  KEY `p_id` (`p_id`),
  KEY `sort` (`sort`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `hong_pcat` VALUES('1', '0', '1', '1', '1', '深沟球轴承', 'DEEP GROOVE BALL BEARING', '', '', '', '', '0');
INSERT INTO `hong_pcat` VALUES('2', '1', '2', '1', '1', '6000 系列', '6000 SERIES', '', '', '', '', '2');
INSERT INTO `hong_pcat` VALUES('3', '0', '3', '1', '1', '圆锥滚子轴承', 'taper roller bearing', '圆锥滚子轴承', '', '', '', '0');



DROP TABLE IF EXISTS `hong_pm`;
CREATE TABLE `hong_pm` (
  `pmid` int(30) NOT NULL AUTO_INCREMENT,
  `refer_id` int(30) NOT NULL DEFAULT '0',
  `toid` int(11) NOT NULL DEFAULT '0',
  `toname` varchar(64) NOT NULL DEFAULT '',
  `fromid` int(11) NOT NULL DEFAULT '0',
  `fromname` varchar(64) NOT NULL DEFAULT '',
  `readed` tinyint(1) NOT NULL DEFAULT '0',
  `newreply` tinyint(1) NOT NULL DEFAULT '0',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` text,
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pmid`),
  KEY `refer_id` (`refer_id`),
  KEY `toid` (`toid`),
  KEY `fromid` (`fromid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;




DROP TABLE IF EXISTS `hong_product`;
CREATE TABLE `hong_product` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_id` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1',
  `is_best` tinyint(1) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `price` varchar(36) NOT NULL DEFAULT '',
  `price_en` varchar(36) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `title_en` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `keywords_en` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext,
  `content_en` mediumtext,
  `clicks` int(11) NOT NULL DEFAULT '0',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`),
  KEY `sort` (`sort`),
  KEY `created` (`created`),
  KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `hong_product` VALUES('1', '2', '1', '1', '1', '1', '系统管理员', '2020/0314', '7dcfb78ade509e4f3f9eb4668322aba1', '', '', '推力球轴承', 'Thrust Ball Bearing', '51100  51200 系列', '51100  51200 series', '&lt;br /&gt;
&lt;table width=&quot;96%&quot; align=&quot;center&quot; cellspacing=&quot;1&quot; style=&quot;font-size:12px;color:#FFFFFF;font-family:Verdana, Arial, Helvetica, sans-serif, 宋体;&quot;&gt;
 &lt;tbody&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    轴承型号
   &lt;/td&gt;
   &lt;td colspan=&quot;4&quot; align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    外型尺寸（mm）
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    重量（kg）
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    d
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    D
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    T
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    rsmin
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51103
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    17
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    9
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.3
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.024
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51203
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    17
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    12
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.048
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51104
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    10
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.3
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.036
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51204
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.075
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51304
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    47
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.146
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    42
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    11
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.055
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51205
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    47
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    15
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.11
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51305
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    52
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.18
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51405
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    24
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.33
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51106
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    47
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    11
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.062
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51206
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    52
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    16
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.13
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51306
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    21
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.27
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51406
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    30
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    28
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.52
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51107
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    52
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    12
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.077
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51207
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    62
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.21
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51307
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    68
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    24
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.38
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51407
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    32
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.76
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51108
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    13
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.11
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51208
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    68
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.26
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51308
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    78
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    26
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.55
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51408
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    36
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.08
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51708ZH
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    67
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14.25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.146
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51109
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.15
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51209
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    73
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    20
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.32
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51309
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    28
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.68
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51409
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    45
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    39
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.43
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.16
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51210
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    78
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    22
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.38
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51310
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    95
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    31
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.95
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51410
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    50
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    43
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.9
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51111
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    78
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    16
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.23
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51211
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.61
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51311
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.29
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51411
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    55
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    48
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.52
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51112
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    17
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.3
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51212
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    95
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    26
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.68
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51312
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.37
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51412
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    130
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    3.12
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51113
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.34
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51213
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.78
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51313
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    115
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    36
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.51
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51413
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    140
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    56
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    3.96
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51114
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    95
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    18
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.36
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51214
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.79
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51314
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    125
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.01
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51414
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    70
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    150
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    60
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    4.86
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51115
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.4
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51215
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.87
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51315
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    135
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    44
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.61
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51415
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    75
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    160
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    65
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    5.97
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51116
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    105
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.42
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51216
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    115
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    28
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.92
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51316
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    140
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    44
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.5
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.72
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51416
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    80
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    170
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    68
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    7.77
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51117
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    19
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.45
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51217
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    85
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    125
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    31
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.25
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51118
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    22
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.69
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51218
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    90
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    135
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    35
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.7
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    135
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51220
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    100
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    150
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    38
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    2.3
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51122
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    110
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    145
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.08
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51124
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    120
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    155
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    1.12
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td colspan=&quot;6&quot; align=&quot;left&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    非标准
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51105K1
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    27
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    43
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    10
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.04
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#C7E5FD&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    51105K2
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    43
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    10
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.041
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr bgcolor=&quot;#F2F2F2&quot;&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    688808
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    40
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    67
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    14.25
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.6
   &lt;/td&gt;
   &lt;td align=&quot;center&quot; class=&quot;hei14&quot; style=&quot;line-height:22px;font-family:宋体;color:#333333;&quot;&gt;
    0.25
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;', '&lt;div style=&quot;text-align:center;&quot;&gt;
 &lt;span style=&quot;color:#974D04;font-family:Arial, Helvetica, sans-serif;font-size:20px;line-height:20px;text-align:center;&quot;&gt;Thrust Ball Bearing&lt;/span&gt;
&lt;/div&gt;
&lt;table width=&quot;600&quot; border=&quot;0&quot; align=&quot;center&quot; cellpadding=&quot;0&quot; cellspacing=&quot;0&quot; style=&quot;color:#000000;font-family:Simsun;text-align:center;&quot; class=&quot;ke-zeroborder&quot;&gt;
 &lt;tbody&gt;
  &lt;tr&gt;
   &lt;td class=&quot;main_4_e&quot; style=&quot;font-size:13px;line-height:20px;font-family:Arial, Helvetica, sans-serif;color:#47472D;text-align:justify;&quot;&gt;
    This type of bearings is separable ,which can only carry axial load,The single direction bearings of them can only carry axial load in one direction,while the double can carry slternating axial load in either diredtion.Before using they have to be preloaded.The thrust ball bearings are used in lathe centers,automobile clutches,reducers and so on ,The double direction angular contact thrust ball bearings are suitable for machine tool spindles,while the single are used to support ball screws.
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td colspan=&quot;4&quot;&gt;
    &lt;table width=&quot;480&quot; border=&quot;0&quot; align=&quot;center&quot; cellpadding=&quot;20&quot; class=&quot;ke-zeroborder&quot;&gt;
     &lt;tbody&gt;
      &lt;tr&gt;
       &lt;td align=&quot;center&quot;&gt;
        &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/03.jpg&quot; alt=&quot;&quot; /&gt;
       &lt;/td&gt;
       &lt;td align=&quot;center&quot;&gt;
        &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/04.jpg&quot; alt=&quot;&quot; /&gt;
       &lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
       &lt;td colspan=&quot;2&quot; align=&quot;center&quot;&gt;
        &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/1-2.jpg&quot; alt=&quot;&quot; /&gt;
       &lt;/td&gt;
      &lt;/tr&gt;
     &lt;/tbody&gt;
    &lt;/table&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;
&lt;table width=&quot;750&quot; border=&quot;0&quot; align=&quot;center&quot; cellpadding=&quot;0&quot; cellspacing=&quot;0&quot; style=&quot;color:#000000;font-family:Simsun;text-align:center;&quot; class=&quot;ke-zeroborder&quot;&gt;
 &lt;tbody&gt;
  &lt;tr&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_01.gif&quot; width=&quot;200&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_02.gif&quot; width=&quot;175&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_03.gif&quot; width=&quot;185&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_04.gif&quot; width=&quot;190&quot; height=&quot;215&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_05.gif&quot; width=&quot;200&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_06.gif&quot; width=&quot;175&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_07.gif&quot; width=&quot;185&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_08.gif&quot; width=&quot;190&quot; height=&quot;190&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_09.gif&quot; width=&quot;200&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_10.gif&quot; width=&quot;175&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_11.gif&quot; width=&quot;185&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
   &lt;td&gt;
    &lt;img src=&quot;http://www.weihengbearing.com/images/sort8/013_12.gif&quot; width=&quot;190&quot; height=&quot;164&quot; alt=&quot;&quot; /&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;', '1', '1584179432');
INSERT INTO `hong_product` VALUES('2', '2', '2', '1', '0', '1', '系统管理员', '2020/0315', '00481e9f150a5b91af4130f2855b2cc4', '', '', '6208N深沟球轴承', '6208N DEEP GROOVE BALL BEARING', '', '', '产品类型：深沟球轴承
&lt;div&gt;
 型号：6208N
&lt;/div&gt;
&lt;div&gt;
 内径：40mm
&lt;/div&gt;
&lt;div&gt;
 外径：80mm
&lt;/div&gt;
&lt;div&gt;
 高度：18mm
&lt;/div&gt;
&lt;div&gt;
 重量：0.359kg
&lt;/div&gt;
&lt;div&gt;
 动载荷：29.80
&lt;/div&gt;
&lt;div&gt;
 静载荷：18.40
&lt;/div&gt;
&lt;div&gt;
 脂转速：8200
&lt;/div&gt;
&lt;div&gt;
 油转速：9700
&lt;/div&gt;
&lt;div&gt;
 钢球数量：9个
&lt;/div&gt;
&lt;div&gt;
 保持器：钢板冲压保持器
&lt;/div&gt;
&lt;div&gt;
 材质：轴承钢，GCR15
&lt;/div&gt;
&lt;div&gt;
 外观：精美，光亮，无划痕，无磕碰伤
&lt;/div&gt;
&lt;div&gt;
 包装：工业包装或单个彩盒包装
&lt;/div&gt;
&lt;div&gt;
 防锈：优质防锈油，质保二年
&lt;/div&gt;
&lt;div&gt;
 产品特点：高转速 寿命长 高精度 低噪音
&lt;/div&gt;
&lt;div&gt;
 安装部位：变速器第一轴后    每车用量：1套     适用车型：BJ2020、BJ212吉普
&lt;/div&gt;
&lt;div&gt;
 安装部位：取力器输出轴前    每车用量：1套     适用车型：红岩CQ3300Z32(16吨)
&lt;/div&gt;
&lt;div&gt;
 安装部位：变速器一轴后        每车用量：1套     适用车型：CA1040、1046（4吨轻卡）
&lt;/div&gt;
&lt;div&gt;
 安装部位：空压机曲轴前        每车用量：1套     适用车型：CA1120PK2L(6平柴)
&lt;/div&gt;
&lt;div&gt;
 临清市普菲轴承有限公司专业生产深沟球轴承，实体工厂，产品100%全检，按您要求来做包装，如有需要，欢迎随时询价！&lt;br /&gt;
&lt;br /&gt;
 &lt;table class=&quot;all magic-10&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-variant-numeric:inherit;font-variant-east-asian:inherit;font-stretch:inherit;font-size:12px;line-height:inherit;font-family:Arial, Helvetica, sans-senif;border-collapse:collapse;width:auto;word-wrap:break-word;color:#333333;&quot;&gt;
  &lt;tbody style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i1.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Bearing Type&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;3&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-18&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:131px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Principal Dimensions&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-22&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:132px;min-height:18px;&quot;&gt;
      &lt;span data-spm-anchor-id=&quot;a2700.details.pronpeci14.i2.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Basic Load Ratings&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-24&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:137px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;limiting Speeds&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Reference weight&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;3&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-18&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:131px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(mm)&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-22&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:132px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(KN)&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-24&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:137px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(r/min)&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(KG)&lt;/span&gt; 
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      d
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      D
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      B
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      Cr
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      Cor
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      Crease
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      Oil
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      Wt
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6200
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      10
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      30
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      7
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      5.1
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      2.39
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      24000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      30000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.032
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6201
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      12
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      32
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      10
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      6.8
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      3.05
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      22000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      28000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.037
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6202
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      15
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      35
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      11
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      7.65
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      3.75
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      20000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      24000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.045
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6203
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      17
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      40
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      12
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      9.55
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      4.8
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      17000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      20000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.067
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6204
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      20
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      47
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      14
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      12.8
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      6.6
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      15000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      18000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.107
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6205
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      25
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      52
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      15
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      1.4
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      7.85
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      13000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      15000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.129
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6206
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      30
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      62
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      16
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      19.5
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i0.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      11.3
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      11000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      13000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.119
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6207
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      35
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      72
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      17
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      25.7
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      15.4
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      8800
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      11000
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.291
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6208
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      40
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      80
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      18
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      30.9
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      19
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      7800
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      9700
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i3.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.366
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6209
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      45
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      85
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      19
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      30.9
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      19.4
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      7200
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      8900
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.413
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6210
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      50
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      90
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      20
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      35.1
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      23.3
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      6700
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      8300
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.467
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6211
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      55
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      100
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      21
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i4.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      43.4
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      29.3
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      6100
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      7500
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.608
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6212
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      60
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      110
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      22
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      47.8
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      33.1
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      5500
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      6800
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.798
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6213
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      65
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      120
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      23
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      57.2
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      40.2
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      5100
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      6300
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      0.974
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6214
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      70
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      125
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      24
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      60.8
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      45.1
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      4800
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      5900
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      1.11
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6215
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      75
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      130
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      25
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      66.1
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      49.6
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      4600
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      5700
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      1.17
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
   &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
      6216
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
      80
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
      140
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
      26
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
      72.7
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
      53.1
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
      4300
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
      5300
     &lt;/div&gt;
    &lt;/td&gt;
    &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
     &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
      1.37
     &lt;/div&gt;
    &lt;/td&gt;
   &lt;/tr&gt;
  &lt;/tbody&gt;
 &lt;/table&gt;
&lt;br /&gt;
&lt;/div&gt;', '&lt;table class=&quot;all magic-10&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-variant-numeric:inherit;font-variant-east-asian:inherit;font-stretch:inherit;font-size:12px;line-height:inherit;font-family:Arial, Helvetica, sans-senif;border-collapse:collapse;width:auto;word-wrap:break-word;color:#333333;&quot;&gt;
 &lt;tbody style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i1.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Bearing Type&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;3&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-18&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:131px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Principal Dimensions&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-22&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:132px;min-height:18px;&quot;&gt;
     &lt;span data-spm-anchor-id=&quot;a2700.details.pronpeci14.i2.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Basic Load Ratings&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-24&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:137px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;limiting Speeds&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;Reference weight&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;3&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-18&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:131px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(mm)&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-22&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:132px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(KN)&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;2&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-24&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:137px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(r/min)&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     &lt;span style=&quot;box-sizing:content-box;font-weight:700;&quot;&gt;(KG)&lt;/span&gt; 
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     d
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     D
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     B
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     Cr
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     Cor
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     Crease
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     Oil
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;2&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     Wt
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6200
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     10
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     30
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     7
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     5.1
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     2.39
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     24000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     30000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.032
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6201
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     12
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     32
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     10
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     6.8
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     3.05
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     22000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     28000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.037
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6202
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     15
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     35
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     11
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     7.65
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     3.75
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     20000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     24000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.045
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6203
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     17
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     40
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     12
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     9.55
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     4.8
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     17000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     20000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.067
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6204
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     20
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     47
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     14
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     12.8
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     6.6
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     15000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     18000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.107
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6205
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     25
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     52
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     15
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     1.4
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     7.85
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     13000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     15000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.129
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6206
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     30
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     62
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     16
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     19.5
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i0.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     11.3
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     11000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     13000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.119
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6207
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     35
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     72
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     17
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     25.7
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     15.4
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     8800
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     11000
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.291
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6208
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     40
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     80
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     18
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     30.9
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     19
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     7800
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     9700
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i3.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.366
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6209
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     45
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     85
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     19
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     30.9
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     19.4
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     7200
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     8900
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.413
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6210
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     50
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     90
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     20
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     35.1
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     23.3
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     6700
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     8300
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.467
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6211
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     55
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     100
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     21
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; data-spm-anchor-id=&quot;a2700.details.pronpeci14.i4.15cd5225Ppac84&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     43.4
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     29.3
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     6100
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     7500
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.608
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6212
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     60
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     110
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     22
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     47.8
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     33.1
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     5500
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     6800
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.798
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6213
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     65
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     120
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     23
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     57.2
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     40.2
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     5100
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     6300
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     0.974
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6214
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     70
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     125
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     24
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     60.8
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     45.1
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     4800
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     5900
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     1.11
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6215
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     75
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     130
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     25
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     66.1
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     49.6
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     4600
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     5700
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     1.17
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;&quot;&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-17&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:88px;min-height:18px;&quot;&gt;
     6216
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-27&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:28px;min-height:18px;&quot;&gt;
     80
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-20&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:30px;min-height:18px;&quot;&gt;
     140
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-21&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:31px;min-height:18px;&quot;&gt;
     26
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-28&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:56px;min-height:18px;&quot;&gt;
     72.7
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-23&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:55px;min-height:18px;&quot;&gt;
     53.1
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-29&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:47px;min-height:18px;&quot;&gt;
     4300
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-25&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:69px;min-height:18px;&quot;&gt;
     5300
    &lt;/div&gt;
   &lt;/td&gt;
   &lt;td colspan=&quot;1&quot; rowspan=&quot;1&quot; style=&quot;box-sizing:content-box;margin:0px;padding:0px;font-style:inherit;font-variant:inherit;font-stretch:inherit;line-height:inherit;font-family:inherit;float:none;border-style:solid;border-color:#CCCCCC;overflow:hidden;height:20px;vertical-align:top;&quot;&gt;
    &lt;div class=&quot;magic-26&quot; style=&quot;box-sizing:content-box;margin:0px;padding:5px 10px;border:0px;font-style:inherit;font-variant:inherit;font-weight:inherit;font-stretch:inherit;font-size:inherit;line-height:inherit;font-family:inherit;vertical-align:baseline;width:108px;min-height:18px;&quot;&gt;
     1.37
    &lt;/div&gt;
   &lt;/td&gt;
  &lt;/tr&gt;
 &lt;/tbody&gt;
&lt;/table&gt;
&lt;br /&gt;
&lt;br type=&quot;_moz&quot; /&gt;
&lt;img src=&quot;/pic/other/2020-03-12-20-49-281.jpg&quot; vspace=&quot;5&quot; hspace=&quot;5&quot; border=&quot;0&quot; alt=&quot;&quot; /&gt;&lt;br /&gt;', '1', '1584241941');



DROP TABLE IF EXISTS `hong_session`;
CREATE TABLE `hong_session` (
  `sessionid` char(32) NOT NULL DEFAULT '',
  `userid` int(11) NOT NULL DEFAULT '0',
  `ipaddress` varchar(32) NOT NULL DEFAULT '',
  `useragent` char(32) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sessionid`),
  KEY `userid` (`userid`),
  KEY `created` (`created`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `hong_session` VALUES('09a2c1953eaab1d855bfaa9b5ab711db', '1', '127.0.0.1', '71a10afe9f5fcd7fc10e40d020fb6143', '1584169972', '1');
INSERT INTO `hong_session` VALUES('e648de83d4d9b3e9ac5f69a2ec50855a', '1', '127.0.0.1', '08bc4d08dd080581a19b641d24734b6b', '1584177354', '1');
INSERT INTO `hong_session` VALUES('fbdbb68826c17cf6e7c3f40810275c47', '1', '127.0.0.1', '08bc4d08dd080581a19b641d24734b6b', '1584239891', '1');



DROP TABLE IF EXISTS `hong_user`;
CREATE TABLE `hong_user` (
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `groupid` int(11) NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `password` varchar(64) NOT NULL DEFAULT '',
  `verifycode` varchar(8) NOT NULL DEFAULT '',
  `joindate` int(11) NOT NULL DEFAULT '0',
  `lastdate` int(11) NOT NULL DEFAULT '0',
  `joinip` varchar(64) NOT NULL DEFAULT '',
  `lastip` varchar(64) NOT NULL DEFAULT '',
  `lang` tinyint(1) NOT NULL DEFAULT '0',
  `loginnum` int(11) NOT NULL DEFAULT '0',
  `p_num` int(11) NOT NULL DEFAULT '0',
  `a_num` int(11) NOT NULL DEFAULT '0',
  `q_num` int(11) NOT NULL DEFAULT '0',
  `pc_num` int(11) NOT NULL DEFAULT '0',
  `ac_num` int(11) NOT NULL DEFAULT '0',
  `nickname` varchar(64) NOT NULL DEFAULT '',
  `email` varchar(128) NOT NULL DEFAULT '',
  `profile` text,
  `company` varchar(225) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `postcode` varchar(32) NOT NULL DEFAULT '',
  `tel` varchar(255) NOT NULL DEFAULT '',
  `fax` varchar(255) NOT NULL DEFAULT '',
  `online` varchar(255) NOT NULL DEFAULT '',
  `website` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  KEY `joindate` (`joindate`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `hong_user` VALUES('1', '1', '1', 'tsh1991', '4c49dc3fc55e22983caa24088c99e8c9', '', '1584169944', '1584239891', 'unknown', '127.0.0.1', '1', '3', '2', '2', '0', '0', '0', '系统管理员', '', NULL, '', '', '', '', '', '', '');



DROP TABLE IF EXISTS `hong_usergroup`;
CREATE TABLE `hong_usergroup` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `grouptype` tinyint(1) NOT NULL DEFAULT '0',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `groupname_en` varchar(64) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `actions` text,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `hong_usergroup` VALUES('1', '1', '超级管理员', 'Administrator', '超级管理员, 具有前后台所有权限, 且权限无法更改', 'all');
INSERT INTO `hong_usergroup` VALUES('2', '0', '注册会员', 'Member', '用户在前台注册后的默认用户组', '*login*comment*enquiry*pmdays:30*');
INSERT INTO `hong_usergroup` VALUES('3', '0', '游客', 'Guest', '前台未注册的浏览者', '*enquiry*');



DROP TABLE IF EXISTS `hong_vvc`;
CREATE TABLE `hong_vvc` (
  `vvcid` int(30) NOT NULL AUTO_INCREMENT,
  `code` varchar(9) NOT NULL DEFAULT '',
  `created` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`vvcid`),
  KEY `created` (`created`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `hong_vvc` VALUES('1', 'DYGJO', '1584256906');
INSERT INTO `hong_vvc` VALUES('2', 'LJUGV', '1584256915');
INSERT INTO `hong_vvc` VALUES('3', 'LUJDA', '1584256984');
INSERT INTO `hong_vvc` VALUES('4', 'QPAHU', '1584257022');
INSERT INTO `hong_vvc` VALUES('5', 'RIHRZ', '1584262132');
INSERT INTO `hong_vvc` VALUES('6', 'XECFY', '1584262374');
INSERT INTO `hong_vvc` VALUES('7', 'NXIM', '1584262745');
INSERT INTO `hong_vvc` VALUES('8', 'JEHXU', '1584262766');
INSERT INTO `hong_vvc` VALUES('9', 'LUHBE', '1584262849');
INSERT INTO `hong_vvc` VALUES('10', 'LXUC', '1584262867');
INSERT INTO `hong_vvc` VALUES('11', 'JEDY', '1584262889');
INSERT INTO `hong_vvc` VALUES('12', 'SIDWA', '1584262907');
INSERT INTO `hong_vvc` VALUES('13', 'PVAPW', '1584263122');
INSERT INTO `hong_vvc` VALUES('14', 'WBYMH', '1584263211');
INSERT INTO `hong_vvc` VALUES('15', 'JLYLY', '1584263356');
INSERT INTO `hong_vvc` VALUES('16', 'XYJD', '1584263415');
INSERT INTO `hong_vvc` VALUES('17', 'RQEL', '1584263460');
INSERT INTO `hong_vvc` VALUES('19', 'XUKR', '1584264423');
INSERT INTO `hong_vvc` VALUES('20', 'FOXHE', '1584264454');
INSERT INTO `hong_vvc` VALUES('21', 'BJERP', '1584264715');
INSERT INTO `hong_vvc` VALUES('22', 'RIMVT', '1584264723');
INSERT INTO `hong_vvc` VALUES('23', 'PUWAX', '1584265035');
INSERT INTO `hong_vvc` VALUES('24', 'HUGXZ', '1584265090');



